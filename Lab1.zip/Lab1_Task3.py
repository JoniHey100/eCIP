# -*- coding: utf-8 -*-
"""
Created on Mon Mar  2 19:08:44 2026

@author: ionat
"""

import numpy as np
import matplotlib.pyplot as plt

# -------------------------
# Parameters
# -------------------------
N = 50
x0 = 0
sigma = 2          # noise std
W = 5              # moving average window (you can change to 3, 5, 10...)

# -------------------------
# True state: x(t+1) = x(t) + 1
# -------------------------
t = np.arange(N)
x = np.zeros(N)
x[0] = x0
for k in range(N - 1):
    x[k + 1] = x[k] + 1

# -------------------------
# Noisy observations: y(t) = x(t) + noise
# -------------------------
noise = np.random.normal(0, sigma, N)
y = x + noise

# -------------------------
# Moving average estimate
# -------------------------
x_hat = np.zeros(N)
for k in range(N):
    start = max(0, k - W + 1)     # handle beginning (not enough past samples)
    x_hat[k] = np.mean(y[start:k+1])

# -------------------------
# Plot all three
# -------------------------
plt.figure()
plt.plot(t, x, label="True state x(t)")
plt.scatter(t, y, label="Noisy observations y(t)", marker="o")
plt.plot(t, x_hat, label=f"Moving average estimate x̂(t), W={W}")
plt.xlabel("Time step t")
plt.ylabel("Value")
plt.title("True State vs Observations vs Moving Average Estimate")
plt.grid()
plt.legend()
plt.show()