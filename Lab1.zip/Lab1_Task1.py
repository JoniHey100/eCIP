# -*- coding: utf-8 -*-
"""
Created on Mon Mar  2 18:24:11 2026

@author: ionat
"""

import numpy as np
import matplotlib.pyplot as plt

# number of steps
N = 50

# initial condition
x0 = 0

# time vector
t = np.arange(N)

# true state generation
x = np.zeros(N)
x[0] = x0

for k in range(N-1):
    x[k+1] = x[k] + 1

# plot
plt.figure()
plt.plot(t, x)
plt.xlabel("Time step t")
plt.ylabel("True state x(t)")
plt.title("Evolution of the True System State")
plt.grid()
plt.show()