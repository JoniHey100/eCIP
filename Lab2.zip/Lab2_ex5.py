# -*- coding: utf-8 -*-
"""
Created on Mon Mar  9 19:22:18 2026

@author: ionat
"""

import numpy as np
import matplotlib.pyplot as plt

# parameters
r = 4
initial_values = [0.1, 0.5, 1.0, 2.0]
N = 50
t = np.arange(N)

fig, axes = plt.subplots(2, 2, figsize=(10,6))

for i, x0 in enumerate(initial_values):
    x = np.zeros(N)
    x[0] = x0

    for k in range(N-1):
        x[k+1] = r * x[k] * (1 - x[k])

    ax = axes[i//2, i%2]
    ax.plot(t, x)
    ax.set_title(f"Initial population x0 = {x0}")
    ax.set_xlabel("Time step")
    ax.set_ylabel("Population x(t)")
    ax.grid()

plt.tight_layout()
plt.show()