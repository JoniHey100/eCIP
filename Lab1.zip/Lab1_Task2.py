# -*- coding: utf-8 -*-
"""
Created on Mon Mar  2 18:45:58 2026

@author: ionat
"""

import numpy as np
import matplotlib.pyplot as plt

# number of steps
N = 50

# initial condition
x0 = 0

# time vector
t = np.arange(N)

# TRUE STATE
x = np.zeros(N)
x[0] = x0

for k in range(N-1):
    x[k+1] = x[k] + 1

# GAUSSIAN NOISE (mean=0, std=2)
noise = np.random.normal(0, 2, N)

# OBSERVATIONS
y = x + noise

# PLOT
plt.figure()
plt.plot(t, x, label="True State x(t)")
plt.scatter(t, y, label="Noisy Observations y(t)", marker='o')
plt.xlabel("Time step t")
plt.ylabel("Value")
plt.title("True State vs Noisy Observations")
plt.legend()
plt.grid()
plt.show()