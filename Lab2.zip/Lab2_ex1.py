# -*- coding: utf-8 -*-
"""
Created on Mon Mar  9 18:29:35 2026

@author: ionat
"""

import numpy as np
import matplotlib.pyplot as plt

# parameters
r = 0.9
N = 50          # number of steps
x0 = 0.2        # initial population

# array for population
x = np.zeros(N)
x[0] = x0

# logistic map simulation
for t in range(N-1):
    x[t+1] = r * x[t] * (1 - x[t])

# plot
t = np.arange(N)

plt.figure()
plt.plot(t, x)
plt.xlabel("Time step")
plt.ylabel("Population x(t)")
plt.title("Population Growth (Logistic Model, r = 0.9)")
plt.grid()
plt.show()