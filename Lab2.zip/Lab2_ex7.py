# -*- coding: utf-8 -*-
"""
Created on Mon Mar  9 19:49:01 2026

@author: ionat
"""

import numpy as np
import matplotlib.pyplot as plt

np.random.seed(42)

# transition probabilities
transitions = {
    'A': {'B': 0.4, 'C': 0.6},
    'B': {'A': 0.5, 'B': 0.5},
    'C': {'A': 0.2, 'B': 0.2, 'C': 0.6}
}

# modified weights
weights = {
    'A': 1.5,
    'B': 0.5,   # changed
    'C': 3.3
}

N = 15
state = 'A'

# generate sequence S
S = [state]
for _ in range(N-1):
    next_states = list(transitions[state].keys())
    probs = list(transitions[state].values())
    state = np.random.choice(next_states, p=probs)
    S.append(state)

print("Sequence S:", S)

# population simulation
x = np.zeros(N+1)
x[0] = 0.5

for t in range(N):
    r = weights[S[t]]
    x[t+1] = r * x[t] * (1-x[t])

# plot
t = np.arange(N+1)

plt.figure()
plt.plot(t, x, marker='o')
plt.xlabel("Step")
plt.ylabel("Population")
plt.title("Population Evolution (Modified weight B = 0.5)")
plt.grid()
plt.show()

print("Population after 15 steps:", x[15])