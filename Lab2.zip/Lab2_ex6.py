# -*- coding: utf-8 -*-
"""
Created on Mon Mar  9 19:26:55 2026

@author: ionat
"""

import numpy as np

# for reproducible results
np.random.seed(42)

# transition probabilities from the diagram
transitions = {
    'A': {'B': 0.4, 'C': 0.6},
    'B': {'A': 0.5, 'B': 0.5},
    'C': {'A': 0.2, 'B': 0.2, 'C': 0.6}
}

# state weights
weights = {
    'A': 1.5,
    'B': 2.0,
    'C': 3.3
}

# number of steps
N = 15

# choose a starting state
current_state = 'A'

# generate sequence S
S = [current_state]
for _ in range(N - 1):
    next_states = list(transitions[current_state].keys())
    probs = list(transitions[current_state].values())
    current_state = np.random.choice(next_states, p=probs)
    S.append(current_state)

print("Sequence S:")
print(S)

# logistic population using weights as r values
x = np.zeros(N + 1)
x[0] = 0.5

for t in range(N):
    r = weights[S[t]]
    x[t + 1] = r * x[t] * (1 - x[t])

print("\nPopulation values:")
for i in range(N + 1):
    print(f"x({i}) = {x[i]}")

print("\nPopulation after 15 steps:", x[15])