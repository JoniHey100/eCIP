# -*- coding: utf-8 -*-
"""
Created on Mon Mar  9 18:47:48 2026

@author: ionat
"""

import numpy as np
import matplotlib.pyplot as plt

# given r values
r_values = [2, 2.25, 1, 1.2, 3.1, 0.5, 4, 4.4, 3, 2.9, 2.8, 1.9, 1.5, 1.4, 7, 3.8, 8]

# parameters
N = 50
x0 = 0.2
t = np.arange(N)

# create subplots
fig, axes = plt.subplots(len(r_values), 1, figsize=(8, 3*len(r_values)))

for i, r in enumerate(r_values):
    x = np.zeros(N)
    x[0] = x0
    
    for k in range(N - 1):
        x[k+1] = r * x[k] * (1 - x[k])
    
    axes[i].plot(t, x)
    axes[i].set_title(f"Population for r = {r}")
    axes[i].set_xlabel("Time step")
    axes[i].set_ylabel("x(t)")
    axes[i].grid()

plt.tight_layout()
plt.show()