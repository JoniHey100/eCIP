# -*- coding: utf-8 -*-
"""
Created on Mon Mar  9 19:12:01 2026

@author: ionat
"""

# r values for the 17 years
r = [2, 2.25, 1, 1.2, 3.1, 0.5, 4, 4.4, 3, 2.9, 2.8, 1.9, 1.5, 1.4, 7, 3.8, 8]

# initial population
x = 0.2

# simulate 17 years
for i in range(len(r)):
    x = r[i] * x * (1 - x)

print("Population in year 17:", x)